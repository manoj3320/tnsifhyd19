package com.sriindu.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hyd19PlacementsAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
