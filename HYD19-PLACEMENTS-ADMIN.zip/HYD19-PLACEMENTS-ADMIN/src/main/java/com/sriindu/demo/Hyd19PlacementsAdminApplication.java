package com.sriindu.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hyd19PlacementsAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(Hyd19PlacementsAdminApplication.class, args);
	}

}
