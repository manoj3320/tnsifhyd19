package com.employeedb;

import java.sql.*;

public class retriveemployeedata {

public static void main(String[] args) {
		
		String dbURL = "jdbc:mysql://localhost:3306/sriindu";
		String username = "root";
		String password = "M3320";
		
		try (Connection conn = DriverManager.getConnection(dbURL, username, password)){
		
			 
			String sql = "SELECT * FROM employeedb";
			 
			Statement statement = conn.createStatement();
			
			ResultSet result = statement.executeQuery(sql);
			 
			int count = 0;
			 
			while (result.next()){
				int employee_id= result.getInt(1);
			    String empolyee_name = result.getString(2);
			    String employee_address = result.getString(3);
			 
			    String output = "User #%d: %d - %s - %s ";
			    System.out.println(String.format(output, ++count, employee_id ,empolyee_name, employee_address));
			}
		} 
		catch (SQLException ex) {
		    ex.printStackTrace();
		}


	}
}
