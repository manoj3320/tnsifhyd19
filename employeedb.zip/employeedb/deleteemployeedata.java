package com.employeedb;

import java.sql.*;

public class deleteemployeedata {
	public static void main(String[] args) {
		
		String dbURL = "jdbc:mysql://localhost:3306/sriindu";
		String username = "root";
		String password = "M3320";
		
		try {
			 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		    String sql = "DELETE FROM employeedb WHERE empolyee_name=?";
		    
		    PreparedStatement statement = conn.prepareStatement(sql);
		    statement.setString(1, "suresh");
		    int rowsDeleted = statement.executeUpdate();
		    if (rowsDeleted > 0) {
		        System.out.println("A user was deleted successfully!");
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
	}


}
