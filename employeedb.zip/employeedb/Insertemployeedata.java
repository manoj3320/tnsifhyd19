package com.employeedb;

import java.sql.*;

public class Insertemployeedata {

	public static void main(String[] args) {
		
		String dbURL = "jdbc:mysql://localhost:3306/sriindu";
		String username = "root";
		String password = "M3320";
		try {
			 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		    String sql = "INSERT INTO employeedb(empolyee_name,employee_address) VALUES (?, ?)";
		    
		    PreparedStatement statement = conn.prepareStatement(sql);
		    statement.setString(1, "Hariprasad");
		    statement.setString(2, "Nalgonda");
		     
		    int rowsInserted = statement.executeUpdate();
		    if (rowsInserted > 0) {
		        System.out.println("A new user was inserted successfully!");
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}

	}

}
