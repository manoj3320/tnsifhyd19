package com.oop.encapsulation;

import com.oop.*;

public class encapsulation2main {
public static void main(String[] args) {
		
		encapsulation2 e2 = new encapsulation2();
		
		e2.setSubject("Science");
		System.out.println(e2.getSubject());
		
		e2.setReport("pass");
		System.out.println(e2.getReport());
		
		e2.setGrade("C");
		System.out.println(e2.getGrade());
		
		e2.setMarks(200);
		System.out.println(e2.getMarks());
		

	}
}
