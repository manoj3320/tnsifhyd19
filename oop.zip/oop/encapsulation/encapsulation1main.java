package com.oop.encapsulation;

import com.oop.*;

public class encapsulation1main {
		
		public static void main(String[] args) {
			
			encapsulation1 e1 = new encapsulation1();
			e1.marks=200;
			System.out.println(e1.marks);
		
	}

}
