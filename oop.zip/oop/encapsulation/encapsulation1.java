package com.oop.encapsulation;

public class encapsulation1 {


		private String subject;
		private String report;
		private String grade;
		public int marks;
	
}
