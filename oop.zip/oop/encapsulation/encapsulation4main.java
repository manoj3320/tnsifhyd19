package com.oop.encapsulation;

import com.oop.encapsulation.*;

public class encapsulation4main {
	
	public static void main(String[] args) {
		
		encapsulation4 e4 = new encapsulation4();
		e4.setAge(25);
		System.out.println(e4.getAge());
		e4.setGender("Male");
		System.out.println(e4.getGender());
		e4.setName("John");
		System.out.println(e4.getName());
	}
}
	
