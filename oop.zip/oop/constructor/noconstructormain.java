package com.oop.constructor;

public class noconstructormain {
	
	public static void main(String[] args) {
		
		noconstructor nc = new noconstructor();
		System.out.println( nc.getColor());
	}

}
