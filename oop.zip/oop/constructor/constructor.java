package com.oop.constructor;

public class constructor {
	
	public constructor() {
		
		// constructor code generator
	}
}
