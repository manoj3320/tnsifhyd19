package com.oop.constructor;

public class noconstructor {
	
	private String color = "RED";

	public String getColor() {
		return color;
	
	}
	
}
