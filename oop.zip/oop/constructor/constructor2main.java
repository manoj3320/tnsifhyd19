package com.oop.constructor;

public class constructor2main {

	public static void main(String[] args) {
		
		constructor2 c2 = new constructor2("Science" , "pass" , "C" , 160);
		System.out.println( c2.promote ());
	}
}
