package com.oop.constructor;

public class constructor1main {
	
	public static void main(String[] args) {
		
		constructor1 c1 = new constructor1();
		System.out.println( c1.promote ());
	}

}

